/**
 * @author hugomarques
 *         2/6/17.
 */
public class Permutation {

    public static void main(String[] args) {

    }
}
