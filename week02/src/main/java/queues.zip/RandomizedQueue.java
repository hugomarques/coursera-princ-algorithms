import java.util.Iterator;

/**
 * @author hugomarques
 *         2/6/17.
 */
public class RandomizedQueue<Item> implements Iterable<Item> {

    public RandomizedQueue() {

    }

    public boolean isEmpty() {
        return false;
    }

    public int size() {
        return 0;
    }

    public void enqueue(Item item) {

    }

    public Item dequeue() {
        return null;
    }

    public Item sample() {
        return null;
    }

    public Iterator<Item> iterator() {
        return null;
    }
}